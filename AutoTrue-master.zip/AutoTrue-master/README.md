# AutoTrue
Slize's Swag Bot.

# Invite Me!
https://discord.com/api/oauth2/authorize?client_id=756857709323616317&permissions=8&scope=bot
